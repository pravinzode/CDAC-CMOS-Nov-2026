DSCH 2.6h
VERSION 7/14/2016 9:21:34 AM
BB(0,-25,144,90)
SYM  #pmos
BB(65,-10,85,10)
TITLE 80 5  #pmos
MODEL 902
PROP   2.0u 0.12u                                                                                                                                                                                                       
REC(66,-5,19,15,r)
VIS 71
PIN(85,-10,0.000,0.000)s
PIN(65,0,0.000,0.000)g
PIN(85,10,0.030,0.070)d
LIG(65,0,71,0)
LIG(73,0,73,0)
LIG(75,6,75,-6)
LIG(77,6,77,-6)
LIG(85,-6,77,-6)
LIG(85,-10,85,-6)
LIG(85,6,77,6)
LIG(85,10,85,6)
VLG  pmos pmos(drain,source,gate);
FSYM
SYM  #pmos
BB(65,20,85,40)
TITLE 80 35  #pmos
MODEL 902
PROP   2.0u 0.12u                                                                                                                                                                                                       
REC(66,25,19,15,r)
VIS 71
PIN(85,20,0.000,0.000)s
PIN(65,30,0.000,0.000)g
PIN(85,40,0.030,0.210)d
LIG(65,30,71,30)
LIG(73,30,73,30)
LIG(75,36,75,24)
LIG(77,36,77,24)
LIG(85,24,77,24)
LIG(85,20,85,24)
LIG(85,36,77,36)
LIG(85,40,85,36)
VLG  pmos pmos(drain,source,gate);
FSYM
SYM  #nmos
BB(30,55,50,75)
TITLE 45 70  #nmos
MODEL 901
PROP   1.0u 0.12u                                                                                                                                                                                                       
REC(31,60,19,15,r)
VIS 71
PIN(50,75,0.000,0.000)s
PIN(30,65,0.000,0.000)g
PIN(50,55,0.030,0.210)d
LIG(40,65,30,65)
LIG(40,71,40,59)
LIG(42,71,42,59)
LIG(50,59,42,59)
LIG(50,55,50,59)
LIG(50,71,42,71)
LIG(50,75,50,71)
VLG  nmos nmos(drain,source,gate);
FSYM
SYM  #nmos
BB(105,55,125,75)
TITLE 120 70  #nmos
MODEL 901
PROP   1.0u 0.12u                                                                                                                                                                                                       
REC(106,60,19,15,r)
VIS 71
PIN(125,75,0.000,0.000)s
PIN(105,65,0.000,0.000)g
PIN(125,55,0.030,0.210)d
LIG(115,65,105,65)
LIG(115,71,115,59)
LIG(117,71,117,59)
LIG(125,59,117,59)
LIG(125,55,125,59)
LIG(125,71,117,71)
LIG(125,75,125,71)
VLG  nmos nmos(drain,source,gate);
FSYM
SYM  #vss
BB(80,82,90,90)
TITLE 84 87  #vss
MODEL 0
PROP                                                                                                                                                                                                            
REC(80,80,0,0,b)
VIS 0
PIN(85,80,0.000,0.000)vss
LIG(85,80,85,85)
LIG(80,85,90,85)
LIG(80,88,82,85)
LIG(82,88,84,85)
LIG(84,88,86,85)
LIG(86,88,88,85)
FSYM
SYM  #clock1
BB(0,-3,15,3)
TITLE 5 0  #clock
MODEL 69
PROP   10.000 10.000                                                                                                                                                                                                       
REC(2,-2,6,4,r)
VIS 71
PIN(15,0,1.500,0.140)clk1
LIG(10,0,15,0)
LIG(5,-2,3,-2)
LIG(9,-2,7,-2)
LIG(10,-3,10,3)
LIG(0,3,0,-3)
LIG(5,2,5,-2)
LIG(7,-2,7,2)
LIG(7,2,5,2)
LIG(3,2,1,2)
LIG(3,-2,3,2)
LIG(10,3,0,3)
LIG(10,-3,0,-3)
FSYM
SYM  #clock2
BB(0,27,15,33)
TITLE 5 30  #clock
MODEL 69
PROP   20.000 20.000                                                                                                                                                                                                       
REC(2,28,6,4,r)
VIS 71
PIN(15,30,1.500,0.140)clk2
LIG(10,30,15,30)
LIG(5,28,3,28)
LIG(9,28,7,28)
LIG(10,27,10,33)
LIG(0,33,0,27)
LIG(5,32,5,28)
LIG(7,28,7,32)
LIG(7,32,5,32)
LIG(3,32,1,32)
LIG(3,28,3,32)
LIG(10,33,0,33)
LIG(10,27,0,27)
FSYM
SYM  #vdd
BB(80,-25,90,-15)
TITLE 83 -19  #vdd
MODEL 1
PROP                                                                                                                                                                                                           
REC(0,0,0,0,)
VIS 71
PIN(85,-15,0.000,0.000)vdd
LIG(85,-15,85,-20)
LIG(85,-20,80,-20)
LIG(80,-20,85,-25)
LIG(85,-25,90,-20)
LIG(90,-20,85,-20)
FSYM
SYM  #light1
BB(138,30,144,44)
TITLE 140 44  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(139,31,4,4,r)
VIS 71
PIN(140,45,0.000,0.000)out1
LIG(143,36,143,31)
LIG(143,31,142,30)
LIG(139,31,139,36)
LIG(142,41,142,38)
LIG(141,41,144,41)
LIG(141,43,143,41)
LIG(142,43,144,41)
LIG(138,38,144,38)
LIG(140,38,140,45)
LIG(138,36,138,38)
LIG(144,36,138,36)
LIG(144,38,144,36)
LIG(140,30,139,31)
LIG(142,30,140,30)
FSYM
CNC(30 0)
CNC(85 75)
CNC(85 55)
CNC(85 45)
CNC(20 30)
LIG(15,0,30,0)
LIG(85,-15,85,-10)
LIG(85,10,85,20)
LIG(15,30,20,30)
LIG(30,65,30,0)
LIG(30,0,65,0)
LIG(50,75,85,75)
LIG(85,80,85,75)
LIG(85,75,125,75)
LIG(50,55,85,55)
LIG(85,40,85,45)
LIG(85,55,125,55)
LIG(140,45,85,45)
LIG(85,45,85,55)
LIG(20,30,20,80)
LIG(20,30,65,30)
LIG(20,80,75,80)
LIG(75,80,75,65)
LIG(75,65,105,65)
FFIG \\172.16.7.206\print\Microwind set up\Export dsch2\NAVO2 151.sch
