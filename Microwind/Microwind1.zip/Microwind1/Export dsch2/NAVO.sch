DSCH 2.6h
VERSION 7/14/2016 9:07:01 AM
BB(-15,-20,144,85)
SYM  #vdd
BB(55,-20,65,-10)
TITLE 58 -14  #vdd
MODEL 1
PROP                                                                                                                                                                                                           
REC(0,0,0,0,)
VIS 71
PIN(60,-10,0.000,0.000)vdd
LIG(60,-10,60,-15)
LIG(60,-15,55,-15)
LIG(55,-15,60,-20)
LIG(60,-20,65,-15)
LIG(65,-15,60,-15)
FSYM
SYM  #light2
BB(138,5,144,19)
TITLE 140 19  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(139,6,4,4,r)
VIS 1
PIN(140,20,0.000,0.000)out2
LIG(143,11,143,6)
LIG(143,6,142,5)
LIG(139,6,139,11)
LIG(142,16,142,13)
LIG(141,16,144,16)
LIG(141,18,143,16)
LIG(142,18,144,16)
LIG(138,13,144,13)
LIG(140,13,140,20)
LIG(138,11,138,13)
LIG(144,11,138,11)
LIG(144,13,144,11)
LIG(140,5,139,6)
LIG(142,5,140,5)
FSYM
SYM  #nmos
BB(70,50,90,70)
TITLE 75 65  #nmos
MODEL 901
PROP   1.0u 0.12u                                                                                                                                                                                                       
REC(70,55,19,15,r)
VIS 2
PIN(70,70,0.000,0.000)s
PIN(90,60,0.000,0.000)g
PIN(70,50,0.030,0.070)d
LIG(80,60,90,60)
LIG(80,66,80,54)
LIG(78,66,78,54)
LIG(70,54,78,54)
LIG(70,50,70,54)
LIG(70,66,78,66)
LIG(70,70,70,66)
VLG  nmos nmos(drain,source,gate);
FSYM
SYM  #clock2
BB(115,2,130,8)
TITLE 125 5  #clock
MODEL 69
PROP   80.000 80.000                                                                                                                                                                                                       
REC(122,3,6,4,r)
VIS 71
PIN(115,5,1.500,0.140)clk2
LIG(120,5,115,5)
LIG(125,7,127,7)
LIG(121,7,123,7)
LIG(120,8,120,2)
LIG(130,2,130,8)
LIG(125,3,125,7)
LIG(123,7,123,3)
LIG(123,3,125,3)
LIG(127,3,129,3)
LIG(127,7,127,3)
LIG(120,2,130,2)
LIG(120,8,130,8)
FSYM
SYM  #vss
BB(65,77,75,85)
TITLE 69 82  #vss
MODEL 0
PROP                                                                                                                                                                                                            
REC(65,75,0,0,b)
VIS 71
PIN(70,75,0.000,0.000)vss
LIG(70,75,70,80)
LIG(65,80,75,80)
LIG(65,83,67,80)
LIG(67,83,69,80)
LIG(69,83,71,80)
LIG(71,83,73,80)
FSYM
SYM  #clock1
BB(-15,2,0,8)
TITLE -10 5  #clock
MODEL 69
PROP   40.000 40.000                                                                                                                                                                                                       
REC(-13,3,6,4,r)
VIS 71
PIN(0,5,1.500,0.140)clk1
LIG(-5,5,0,5)
LIG(-10,3,-12,3)
LIG(-6,3,-8,3)
LIG(-5,2,-5,8)
LIG(-15,8,-15,2)
LIG(-10,7,-10,3)
LIG(-8,3,-8,7)
LIG(-8,7,-10,7)
LIG(-12,7,-14,7)
LIG(-12,3,-12,7)
LIG(-5,8,-15,8)
LIG(-5,2,-15,2)
FSYM
SYM  #pmos
BB(10,-5,30,15)
TITLE 25 10  #pmos
MODEL 902
PROP   2.0u 0.12u                                                                                                                                                                                                       
REC(11,0,19,15,r)
VIS 2
PIN(30,-5,0.000,0.000)s
PIN(10,5,0.000,0.000)g
PIN(30,15,0.030,0.210)d
LIG(10,5,16,5)
LIG(18,5,18,5)
LIG(20,11,20,-1)
LIG(22,11,22,-1)
LIG(30,-1,22,-1)
LIG(30,-5,30,-1)
LIG(30,11,22,11)
LIG(30,15,30,11)
VLG  pmos pmos(drain,source,gate);
FSYM
SYM  #pmos
BB(85,-5,105,15)
TITLE 90 10  #pmos
MODEL 902
PROP   2.0u 0.12u                                                                                                                                                                                                       
REC(85,0,19,15,r)
VIS 2
PIN(85,-5,0.000,0.000)s
PIN(105,5,0.000,0.000)g
PIN(85,15,0.030,0.210)d
LIG(105,5,99,5)
LIG(97,5,97,5)
LIG(95,11,95,-1)
LIG(93,11,93,-1)
LIG(85,-1,93,-1)
LIG(85,-5,85,-1)
LIG(85,11,93,11)
LIG(85,15,85,11)
VLG  pmos pmos(drain,source,gate);
FSYM
SYM  #nmos
BB(50,25,70,45)
TITLE 65 40  #nmos
MODEL 901
PROP   1.0u 0.12u                                                                                                                                                                                                       
REC(51,30,19,15,r)
VIS 2
PIN(70,45,0.000,0.000)s
PIN(50,35,0.000,0.000)g
PIN(70,25,0.030,0.210)d
LIG(60,35,50,35)
LIG(60,41,60,29)
LIG(62,41,62,29)
LIG(70,29,62,29)
LIG(70,25,70,29)
LIG(70,41,62,41)
LIG(70,45,70,41)
VLG  nmos nmos(drain,source,gate);
FSYM
CNC(70 20)
CNC(110 5)
CNC(60 -5)
CNC(70 15)
LIG(0,5,10,5)
LIG(30,15,70,15)
LIG(60,-10,60,-5)
LIG(70,15,85,15)
LIG(110,5,110,60)
LIG(70,15,70,20)
LIG(10,35,50,35)
LIG(90,60,110,60)
LIG(110,5,115,5)
LIG(70,20,70,25)
LIG(105,5,110,5)
LIG(70,20,140,20)
LIG(70,45,70,50)
LIG(30,-5,60,-5)
LIG(60,-5,85,-5)
LIG(10,5,10,35)
LIG(70,70,70,75)
FFIG \\172.16.7.206\print\Microwind set up\Export dsch2\NAVO.sch
